package com.tecet;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class question5{
    public static void main(String[] args) {
        Integer[] crates = {0, 1, 0, 3, 12, 0, 5};
        List<Integer> result = Arrays.stream(crates)
                                     .filter(crate -> crate != 0)  
                                     .collect(Collectors.toList());
        long emptyCratesCount = Arrays.stream(crates)
                                      .filter(crate -> crate == 0)
                                      .count();
        result.addAll(IntStream.range(0, (int) emptyCratesCount)
                               .mapToObj(i -> 0)
                               .collect(Collectors.toList()));
         Integer[] rearrangedCrates = result.toArray(new Integer[0]);
        System.out.println("Rearranged Crates: " + Arrays.toString(rearrangedCrates));
    }
}
