package com.tecet;

public class question2 implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static void main(String[] args) {
        question2 printer = new question2();
        Thread thread = new Thread(printer);
        thread.start();
    }
}