package com.tecet;

public class question1 interface Sayable {
    String say(String name);
}

public class Main {
    public static void main(String[] args) {
        Sayable sayable = (name) -> "Hello, " + name + "!;
        System.out.println(sayable.say("John"));  
        System.out.println(sayable.say("Alice")); 
    }
}
 


